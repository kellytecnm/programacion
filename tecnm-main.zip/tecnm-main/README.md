Todos los problemas que ha dejado alrededor del semestre, gracias 
